-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: my_schema
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `2014302580147_cart`
--

LOCK TABLES `2014302580147_cart` WRITE;
/*!40000 ALTER TABLE `2014302580147_cart` DISABLE KEYS */;
INSERT INTO `2014302580147_cart` VALUES (15,'turtle',8,2,'12345'),(16,'hamster',12,1,'12345'),(17,'cat',100,1,'12345');
/*!40000 ALTER TABLE `2014302580147_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `2014302580147_order`
--

LOCK TABLES `2014302580147_order` WRITE;
/*!40000 ALTER TABLE `2014302580147_order` DISABLE KEYS */;
INSERT INTO `2014302580147_order` VALUES (1,436,'Allen','12593645822','430079','橘子海滩','','Paid','admin'),(2,564,'Mike','15896548577','430079','橘子海滩','','Waiting For Paying','admin'),(3,364,'Allen','15632598744','430079','橘子海滩','','Paid','admin');
/*!40000 ALTER TABLE `2014302580147_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `2014302580147_pet`
--

LOCK TABLES `2014302580147_pet` WRITE;
/*!40000 ALTER TABLE `2014302580147_pet` DISABLE KEYS */;
INSERT INTO `2014302580147_pet` VALUES (1,'dog','bone','water','ground','play',6,50),(2,'cat','fish','milk','roof','hug',6,100),(3,'turtle','fish,shrimp','sea water','sea water','bask',10,8),(4,'parrot','nuts,seeds','water','tree','fly',2,20),(5,'hamster','Sunflower seed','water','corner','eat',6,12),(6,'squirrel','pine cone','water','tree hole,underground','play',2,5),(7,'rabbit','carrot','water','grassland,underground','eat',16,6),(8,'snake','mouse','water','hole','bask',1,69),(9,'lizard','bug','water','tree','bask',7,16),(10,'fish','aquatic plant','water','water','swim',45,2),(11,'myna','earthworm','water','tree','fly',6,25),(12,'canary','millet','water','tree','sing',0,200);
/*!40000 ALTER TABLE `2014302580147_pet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `2014302580147_user`
--

LOCK TABLES `2014302580147_user` WRITE;
/*!40000 ALTER TABLE `2014302580147_user` DISABLE KEYS */;
INSERT INTO `2014302580147_user` VALUES (1,'admin','admin','wanderlust030@163.com'),(2,'12345','12345','435379068@qq.com');
/*!40000 ALTER TABLE `2014302580147_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-13 22:31:15
