import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainPageGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	Pet pet = new Pet();
	PetService petService = new PetService();

	/**
	 * Create the frame.
	 */
	public MainPageGUI() {
		setResizable(false);
		setTitle("\u5BA0\u7269\u4EA4\u6613\u5E73\u53F0|\u6B22\u8FCE");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 499, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel(">> \u5BA0\u7269\u7C7B\u522B");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label.setBounds(35, 26, 111, 31);
		contentPane.add(label);
		
		JButton btnDog = new JButton("Dog");
		btnDog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				pet = petService.searchPet("dog");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnDog.setFont(new Font("Candara", Font.BOLD, 14));
		btnDog.setBounds(35, 74, 100, 100);
		contentPane.add(btnDog);
		
		JButton btnCat = new JButton("Cat");
		btnCat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("cat");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnCat.setFont(new Font("Candara", Font.BOLD, 14));
		btnCat.setBounds(145, 74, 100, 100);
		contentPane.add(btnCat);
		
		JButton btnTurtle = new JButton("Turtle");
		btnTurtle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("turtle");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnTurtle.setFont(new Font("Candara", Font.BOLD, 14));
		btnTurtle.setBounds(255, 74, 100, 100);
		contentPane.add(btnTurtle);
		
		JButton btnParrot = new JButton("Parrot");
		btnParrot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("parrot");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnParrot.setFont(new Font("Candara", Font.BOLD, 14));
		btnParrot.setBounds(365, 74, 100, 100);
		contentPane.add(btnParrot);
		
		JButton btnHamster = new JButton("Hamster");
		btnHamster.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("hamster");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnHamster.setFont(new Font("Candara", Font.BOLD, 14));
		btnHamster.setBounds(35, 184, 100, 100);
		contentPane.add(btnHamster);
		
		JButton btnSquirrel = new JButton("Squirrel");
		btnSquirrel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("squirrel");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnSquirrel.setFont(new Font("Candara", Font.BOLD, 14));
		btnSquirrel.setBounds(145, 184, 100, 100);
		contentPane.add(btnSquirrel);
		
		JButton btnRabbit = new JButton("Rabbit");
		btnRabbit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("rabbit");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnRabbit.setFont(new Font("Candara", Font.BOLD, 14));
		btnRabbit.setBounds(255, 184, 100, 100);
		contentPane.add(btnRabbit);
		
		JButton btnSnake = new JButton("Snake");
		btnSnake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("snake");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnSnake.setFont(new Font("Candara", Font.BOLD, 14));
		btnSnake.setBounds(365, 184, 100, 100);
		contentPane.add(btnSnake);
		
		JButton btnLizard = new JButton("Lizard");
		btnLizard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("lizard");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnLizard.setFont(new Font("Candara", Font.BOLD, 14));
		btnLizard.setBounds(35, 294, 100, 100);
		contentPane.add(btnLizard);
		
		JButton btnFish = new JButton("Fish");
		btnFish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("fish");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnFish.setFont(new Font("Candara", Font.BOLD, 14));
		btnFish.setBounds(145, 294, 100, 100);
		contentPane.add(btnFish);
		
		JButton btnMyna = new JButton("Myna");
		btnMyna.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("myna");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnMyna.setFont(new Font("Candara", Font.BOLD, 14));
		btnMyna.setBounds(255, 294, 100, 100);
		contentPane.add(btnMyna);
		
		JButton btnCanary = new JButton("Canary");
		btnCanary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pet = petService.searchPet("canary");
				DetailPageGUI detailPage = new DetailPageGUI();
				detailPage.setVisible(true);
				detailPage.writeDetails(pet.getName(), pet.getEat(), pet.getDrink(), pet.getLive(), 
						pet.getHobby(), pet.getInventory(), pet.getPrice());
			}
		});
		btnCanary.setFont(new Font("Candara", Font.BOLD, 14));
		btnCanary.setBounds(365, 294, 100, 100);
		contentPane.add(btnCanary);
		
		JButton button = new JButton("\u6211\u7684\u8D2D\u7269\u8F66");
		button.setBounds(365, 10, 100, 23);
		contentPane.add(button);
		
		JLabel lblUser = new JLabel("");
		lblUser.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		lblUser.setBounds(291, 14, 64, 15);
		contentPane.add(lblUser);
		lblUser.setText(UserNow.getUsernameNow());
		
		JLabel label_1 = new JLabel("\u7528\u6237\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_1.setBounds(255, 14, 36, 15);
		contentPane.add(label_1);
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CartGUI cart = new CartGUI();
				cart.setVisible(true);
			}
		});
	}
}
