
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JSpinner;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DetailPageGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	//private List<Cart> cartList = new ArrayList<Cart>();
	private CartService cartService = new CartService();
	private PetService petService = new PetService();
	private String petName;
	private double petPrice;
	private int petAmount;
	private int petInventory;
	
	JLabel lblName = new JLabel("");
	JLabel lblEat_cont = new JLabel("");
	JLabel lblDrink_cont = new JLabel("");
	JLabel lblLive_cont = new JLabel("");
	JLabel lblHobby_cont = new JLabel("");
	JLabel lblInventory_cont = new JLabel("");
	JLabel lblPrice_cont = new JLabel("");

	/**
	 * Create the frame.
	 */
	public DetailPageGUI() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 316, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//JLabel lblName = new JLabel("");
		lblName.setFont(new Font("Candara", Font.PLAIN, 20));
		lblName.setBounds(136, 10, 117, 40);
		contentPane.add(lblName);
		
		JLabel lblEat = new JLabel("Eat :");
		lblEat.setFont(new Font("Candara", Font.BOLD, 14));
		lblEat.setBounds(10, 67, 54, 15);
		contentPane.add(lblEat);
		
		JLabel lblDrink = new JLabel("Drink :");
		lblDrink.setFont(new Font("Candara", Font.BOLD, 14));
		lblDrink.setBounds(10, 92, 54, 15);
		contentPane.add(lblDrink);
		
		JLabel lblLive = new JLabel("Live :");
		lblLive.setFont(new Font("Candara", Font.BOLD, 14));
		lblLive.setBounds(10, 117, 54, 15);
		contentPane.add(lblLive);
		
		JLabel lblHobby = new JLabel("Hobby :");
		lblHobby.setFont(new Font("Candara", Font.BOLD, 14));
		lblHobby.setBounds(10, 142, 54, 15);
		contentPane.add(lblHobby);
		
		JLabel lblNewLabel_1 = new JLabel(". . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .");
		lblNewLabel_1.setFont(new Font("Candara", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(10, 158, 301, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblInventory = new JLabel("INVENTORY");
		lblInventory.setFont(new Font("Candara", Font.BOLD, 14));
		lblInventory.setBounds(10, 183, 76, 15);
		contentPane.add(lblInventory);
		
		JLabel lblPrice = new JLabel("PRICE($)");
		lblPrice.setFont(new Font("Candara", Font.BOLD, 14));
		lblPrice.setBounds(10, 208, 76, 15);
		contentPane.add(lblPrice);
		
		//JLabel lblEat_cont = new JLabel("");
		lblEat_cont.setFont(new Font("Candara", Font.PLAIN, 14));
		lblEat_cont.setBounds(83, 65, 203, 15);
		contentPane.add(lblEat_cont);
		
		//JLabel lblDrink_cont = new JLabel("");
		lblDrink_cont.setFont(new Font("Candara", Font.PLAIN, 14));
		lblDrink_cont.setBounds(83, 90, 203, 15);
		contentPane.add(lblDrink_cont);
		
		//JLabel lblLive_cont = new JLabel("");
		lblLive_cont.setFont(new Font("Candara", Font.PLAIN, 14));
		lblLive_cont.setBounds(83, 115, 203, 15);
		contentPane.add(lblLive_cont);
		
		//JLabel lblHobby_cont = new JLabel("");
		lblHobby_cont.setFont(new Font("Candara", Font.PLAIN, 14));
		lblHobby_cont.setBounds(83, 140, 203, 15);
		contentPane.add(lblHobby_cont);
		
		//JLabel lblnventory_cont = new JLabel("");
		lblInventory_cont.setFont(new Font("Candara", Font.PLAIN, 14));
		lblInventory_cont.setBounds(96, 181, 129, 15);
		contentPane.add(lblInventory_cont);
		
		//JLabel lblPrice_cont = new JLabel("");
		lblPrice_cont.setFont(new Font("Candara", Font.PLAIN, 14));
		lblPrice_cont.setBounds(96, 206, 129, 15);
		contentPane.add(lblPrice_cont);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(238, 266, 48, 22);
		contentPane.add(spinner);
		
		JButton btnBuy = new JButton("Add to MyCart");
		btnBuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				petAmount = Integer.parseInt(String.valueOf(spinner.getValue()));
				if(petAmount < 1) {
					JOptionPane.showMessageDialog(null, "��ѡ������", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(petAmount > petInventory) {
					JOptionPane.showMessageDialog(null, "��治�㣬������ѡ������", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(cartService.addToCart(petName, petPrice, petAmount)) {
					int newInventory = petInventory - petAmount;
					petService.updateInventory(petName, newInventory);
					lblInventory_cont.setText(String.valueOf(newInventory));
					JOptionPane.showMessageDialog(null, "�ɹ����빺�ﳵ��", "��ʾ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ�", "������Ϣ", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnBuy.setFont(new Font("Candara", Font.PLAIN, 12));
		btnBuy.setBounds(175, 298, 111, 23);
		contentPane.add(btnBuy);
		
		JLabel lblAmount = new JLabel("choose amount");
		lblAmount.setFont(new Font("Candara", Font.PLAIN, 12));
		lblAmount.setBounds(148, 271, 80, 15);
		contentPane.add(lblAmount);
	}
	
	public void writeDetails(String name, String eat, String drink, String live, String hobby, 
			int inventory, double price){
		petName = name;
		petPrice = price;
		petInventory = inventory;
		lblName.setText(name);
		lblEat_cont.setText(eat);
		lblDrink_cont.setText(drink);
		lblLive_cont.setText(live);
		lblHobby_cont.setText(hobby);
		lblInventory_cont.setText(String.valueOf(inventory));
		lblPrice_cont.setText(String.valueOf(price));		
	}
}
