
public class UserNow {
	private static String usernameNow;

	public static String getUsernameNow() {
		return usernameNow;
	}

	public static void setUsernameNow(String usernameNow) {
		UserNow.usernameNow = usernameNow;
	}

}
