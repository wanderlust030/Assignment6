import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CartService {
	String sql = null;
	PreparedStatement ps = null;
	String usernameNow = UserNow.getUsernameNow();
	public boolean addToCart(String petName, double petPrice, int petAmount){
		Connection conn = DBHelper.getConn();
		sql = "insert into 2014302580147_cart (petName, petPrice, petAmount, username) "
				+ "values ('" + petName + "', '" + petPrice + "', '" + petAmount + "','" + usernameNow + "')";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean deleteByID(int id){
		Connection conn = DBHelper.getConn();
		sql = "delete from 2014302580147_cart where id = '" + id + "'";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void deleteByName(){
		Connection conn = DBHelper.getConn();
		sql = "delete from 2014302580147_cart where username = '" + UserNow.getUsernameNow() + "'";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public Cart getCartByID(int id){
		Connection conn = DBHelper.getConn();
		sql = "select * from 2014302580147_cart where id = '" + id + "'";
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Cart cart = new Cart();
				cart.setId(rs.getInt("id"));
				cart.setPetName(rs.getString("petName"));
				cart.setPetPrice(rs.getDouble("petPrice"));
				cart.setPetAmount(rs.getInt("petAmount"));
				return cart;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public double getTotalMoney(){
		Connection conn = DBHelper.getConn();
		sql = "select * from 2014302580147_cart";
		double totalMoney = 0;
		double temp = 0;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int amount = rs.getInt("petAmount");
				double price = rs.getDouble("petPrice");
				temp = price * amount;
				totalMoney += temp;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return totalMoney;
		
	}

}
