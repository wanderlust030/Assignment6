import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import javax.swing.JTable;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CartGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	
	String[] columnNames = {"ID", "Pet Name", "Pet Price($)", "Pet Amount"};
	private JTable table;
	private JTextField idField;
	
	private String usernameNow = UserNow.getUsernameNow();
	CartService cartService = new CartService();
	PetService petService = new PetService();
/**
	 * Create the frame.
	 */
	public CartGUI() {
		setResizable(false);
		setTitle("\u5BA0\u7269\u4EA4\u6613\u5E73\u53F0|\u6211\u7684\u8D2D\u7269\u8F66");
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 461, 304);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		idField = new JTextField();
		idField.setColumns(10);
		
		JButton btnDeleteByID = new JButton("\u5220\u9664");
		btnDeleteByID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = Integer.parseInt(idField.getText());
				Cart cart = cartService.getCartByID(id);
				int amount = cart.getPetAmount();
				String name = cart.getPetName();
				if(cartService.deleteByID(id)) {
					int oldInventory = petService.getInventory(name);
					int newInventory = oldInventory + amount;
					petService.updateInventory(name, newInventory);
					JOptionPane.showMessageDialog(null, "ɾ���ɹ��������²鿴���ﳵ", "��ʾ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Candara", Font.PLAIN, 12));
		
		JButton btnPay = new JButton("\u7ED3\u7B97");
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OrderPageGUI orderGUI = new OrderPageGUI();
				orderGUI.setVisible(true);
				setVisible(false);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(idField, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnDeleteByID, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 235, Short.MAX_VALUE)
							.addComponent(btnPay)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(12)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 199, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(idField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel)
						.addComponent(btnDeleteByID)
						.addComponent(btnPay))
					.addGap(29))
		);
		List<Cart> cartList = getCartList();
		MyTableModel tm = new MyTableModel(cartList);
		table = new JTable(tm);
		scrollPane.setViewportView(table);
		contentPane.setLayout(gl_contentPane);

	}
	
	private List<Cart> getCartList() {
		// TODO Auto-generated method stub
		List<Cart> cartList = new ArrayList();
		Connection conn = DBHelper.getConn();
		String sql = "select * from 2014302580147_cart where username = '" + usernameNow + "'";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Cart cart = new Cart();
				cart.setId(rs.getInt("id"));
				cart.setPetName(rs.getString("petName"));
				cart.setPetPrice(rs.getDouble("petPrice"));
				cart.setPetAmount(rs.getInt("petAmount"));
				cartList.add(cart);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cartList;
	}

	class MyTableModel implements TableModel{
		private List<Cart> cartList;
		
		public MyTableModel(List<Cart> cartList){
			this.cartList = cartList;
		}

		@Override
		public void addTableModelListener(TableModelListener l) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Class<?> getColumnClass(int columnIndex) {
			// TODO Auto-generated method stub
			if(columnIndex == 0 || columnIndex == 3) return int.class;
			else if(columnIndex == 2) return double.class;
			else return String.class;
		}

		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 4;
		}

		@Override
		public String getColumnName(int columnIndex) {
			// TODO Auto-generated method stub
			return columnNames[columnIndex];

		}

		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return cartList.size();
		}

		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
			Cart cart = cartList.get(rowIndex);
			if(columnIndex == 0) {
				return cart.getId();
			} else if(columnIndex == 1) {
				return cart.getPetName();
			} else if(columnIndex == 2) {
				return cart.getPetPrice();
			} else if(columnIndex == 3) {
				return cart.getPetAmount();
			}
			return null;
		}

		@Override
		public boolean isCellEditable(int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
			/*if(columnIndex == 3) {
				return true;
			}*/
			return false;
		}

		@Override
		public void removeTableModelListener(TableModelListener l) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
		}
		
	}
}
