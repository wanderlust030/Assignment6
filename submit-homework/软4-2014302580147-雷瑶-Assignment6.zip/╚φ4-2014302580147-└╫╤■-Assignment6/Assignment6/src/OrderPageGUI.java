
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class OrderPageGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField nameField;
	private JTextField phoneField;
	private JTextField mailField;
	private JTextField addField;
	private JTextField stmtField;
	
	double totalMoney;
	String name;
	String phone;
	String mail;
	String address;
	String stmt;
	
	/**
	 * Create the frame.
	 */
	public OrderPageGUI() {
		totalMoney = getTotalMoney();
		
		setResizable(false);
		setTitle("\u5BA0\u7269\u4EA4\u6613\u5E73\u53F0|\u7ED3\u7B97");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 430, 428);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u603B\u91D1\u989D\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		label.setBounds(10, 30, 65, 19);
		contentPane.add(label);
		
		JLabel money_cont = new JLabel("");
		money_cont.setFont(new Font("Candara", Font.PLAIN, 16));
		money_cont.setBounds(86, 34, 103, 15);
		contentPane.add(money_cont);
		money_cont.setText(String.valueOf(totalMoney));
		
		JLabel label_1 = new JLabel("[ \u6536\u8D27\u4FE1\u606F ]");
		label_1.setFont(new Font("΢���ź�", Font.BOLD, 12));
		label_1.setBounds(10, 84, 74, 15);
		contentPane.add(label_1);
		
		JLabel label_4 = new JLabel("\u59D3\u540D");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_4.setBounds(10, 109, 54, 15);
		contentPane.add(label_4);
		
		nameField = new JTextField();
		nameField.setBounds(85, 106, 132, 21);
		contentPane.add(nameField);
		nameField.setColumns(10);
		
		JLabel label_5 = new JLabel("\u624B\u673A\u53F7\u7801");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_5.setBounds(10, 144, 54, 15);
		contentPane.add(label_5);
		
		phoneField = new JTextField();
		phoneField.setColumns(10);
		phoneField.setBounds(85, 141, 132, 21);
		contentPane.add(phoneField);
		
		JLabel label_6 = new JLabel("\u90AE\u653F\u7F16\u7801");
		label_6.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_6.setBounds(10, 175, 54, 15);
		contentPane.add(label_6);
		
		mailField = new JTextField();
		mailField.setColumns(10);
		mailField.setBounds(85, 172, 132, 21);
		contentPane.add(mailField);
		
		JLabel label_7 = new JLabel("\u6536\u8D27\u5730\u5740");
		label_7.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_7.setBounds(10, 209, 54, 15);
		contentPane.add(label_7);
		
		addField = new JTextField();
		addField.setBounds(85, 206, 316, 21);
		contentPane.add(addField);
		addField.setColumns(10);
				
		JLabel label_3 = new JLabel("\u5907\u6CE8");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_3.setBounds(10, 247, 54, 15);
		contentPane.add(label_3);
		
		stmtField = new JTextField();
		stmtField.setBounds(85, 244, 316, 21);
		contentPane.add(stmtField);
		stmtField.setColumns(10);
		
		JButton btnPay = new JButton("\u4ED8\u6B3E");
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(nameField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "��������Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(phoneField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "�յ绰���벻��Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(mailField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "�������벻��Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(addField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "�ջ���ַ����Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
								
				name = nameField.getText();
				phone = phoneField.getText();
				mail = mailField.getText();
				address = addField.getText();
				stmt = stmtField.getText();
				

				PayGUI payGUI = new PayGUI();
				payGUI.getValue(totalMoney, name, phone, mail, address, stmt);
				payGUI.setVisible(true);
				setVisible(false);
			}
		});
		btnPay.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnPay.setBounds(159, 306, 114, 23);
		contentPane.add(btnPay);
	}
	
	public double getTotalMoney(){
		CartService cartService = new CartService();
		double totalMoney = cartService.getTotalMoney();
		return totalMoney;		
	}
}
