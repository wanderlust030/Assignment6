import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserService {
	String sql = null;
	PreparedStatement ps = null;
	
	public boolean nameExists(String username){
		Connection conn = DBHelper.getConn();
		sql = "select id from 2014302580147_user where username = '" + username + "'";
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean emailExists(String email){
		Connection conn = DBHelper.getConn();
		sql = "select id from 2014302580147_user where email = '" + email + "'";
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean verify(String username, String password){
		Connection conn = DBHelper.getConn();
		sql = "select password from 2014302580147_user where username = '" + username + "'";
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			String pw = null;
			while(rs.next()) {
				pw = rs.getString("password");
			}
			if(pw.equals(password)) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean addUser(User user){
		Connection conn = DBHelper.getConn();
		sql = "insert into 2014302580147_user (username, password, email) "
				+ "values ('" + user.getUsername() + "', '" + user.getPassword() + "', '" + user.getEmail() + "')";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
}
