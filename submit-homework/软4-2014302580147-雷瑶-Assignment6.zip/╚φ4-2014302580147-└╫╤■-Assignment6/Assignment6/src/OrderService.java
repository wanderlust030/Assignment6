import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderService {
	String sql = null;
	PreparedStatement ps = null;
	String usernameNow = UserNow.getUsernameNow();
	
	public boolean createOrder(double money, String name, String phone, String mail,String address, String stmt){
		Connection conn = DBHelper.getConn();
		sql = "insert into 2014302580147_order (money, name, phone, mail, address, statement, username) "
				+ "values ('" + money + "', '" + name + "', '" + phone + "', '" + mail + "','" + address + "', '" + stmt + "', '" + usernameNow + "')";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;		
	}
	
	public void changeOrderState(int id){
		Connection conn = DBHelper.getConn();
		sql = "update 2014302580147_order set state = 'Paid' where id = '" + id + "'";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public int getOrderId(double money, String name){
		Connection conn = DBHelper.getConn();
		sql = "select id from 2014302580147_order where username = '" + UserNow.getUsernameNow() + "' and money = '" + money + "' and name = '" + name + "'";
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.last()) {
				return rs.getInt("id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 0;
	}
	

}
