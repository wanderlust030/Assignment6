import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class LoginGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernameField;
	private JPasswordField passwordField;
		
	User user = new User();
	UserService userService = new UserService();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		setTitle("\u5BA0\u7269\u4EA4\u6613\u5E73\u53F0 - \u767B\u5F55");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcome = new JLabel("W e l c o m e");
		lblWelcome.setFont(new Font("Candara", Font.PLAIN, 20));
		lblWelcome.setBounds(174, 23, 108, 25);
		contentPane.add(lblWelcome);
		
		usernameField = new JTextField();
		usernameField.setBounds(142, 58, 176, 21);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(142, 92, 176, 21);
		contentPane.add(passwordField);
		
		JLabel usernameLbl = new JLabel("\u7528\u6237\u540D");
		usernameLbl.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		usernameLbl.setBounds(76, 64, 41, 15);
		contentPane.add(usernameLbl);
		
		JLabel passwordLbl = new JLabel("\u5BC6\u7801");
		passwordLbl.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		passwordLbl.setBounds(76, 95, 54, 15);
		contentPane.add(passwordLbl);
		
		JButton registerBtn = new JButton("\u6CE8\u518C");
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterGUI register = new RegisterGUI();
				register.setVisible(true);
			}
		});
		registerBtn.setBounds(369, 10, 65, 23);
		contentPane.add(registerBtn);
		
		JButton loginBtn = new JButton("\u767B\u5F55");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user.setUsername(usernameField.getText());
				user.setPassword(String.valueOf(passwordField.getPassword()));
				String username = user.getUsername();
				String password = user.getPassword();
				if(username.isEmpty()) {
					JOptionPane.showMessageDialog(null, "�û�������Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(password.isEmpty()) {
					JOptionPane.showMessageDialog(null, "���벻��Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(! userService.nameExists(username)) {
					JOptionPane.showMessageDialog(null, "�û��������ڣ�����ע��", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(! userService.verify(username, password)) {
					JOptionPane.showMessageDialog(null, "�������", "������Ϣ", JOptionPane.ERROR_MESSAGE);
				} else {
					UserNow.setUsernameNow(username);
					MainPageGUI mainPage = new MainPageGUI();
					mainPage.setVisible(true);
					setVisible(false);
				}
			}
		});
		loginBtn.setBounds(142, 133, 176, 23);
		contentPane.add(loginBtn);
	}
}
