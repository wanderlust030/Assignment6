import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBHelper {
    private static String dbDriver="com.mysql.jdbc.Driver";   
    private static String dbUrl="jdbc:mysql://localhost:3306/my_schema?"; 
    private static String dbUser="root";  
    private static String dbPass="123456";  
    
    public static Connection getConn()  
    {  
        Connection conn=null;  
        try {  
            Class.forName(dbDriver);  
        } catch (ClassNotFoundException e) {  
            e.printStackTrace();  
        }  
        try {  
            conn = DriverManager.getConnection(dbUrl,dbUser,dbPass);  
        } catch (SQLException e) {  
            e.printStackTrace();  
        }  
        return conn;  
    }  
	
}