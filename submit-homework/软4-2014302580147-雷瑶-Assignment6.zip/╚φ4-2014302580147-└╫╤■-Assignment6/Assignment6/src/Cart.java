
public class Cart {
	private int id;
	private String petName;
	private double petPrice;
	private int petAmount;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
	public double getPetPrice() {
		return petPrice;
	}
	public void setPetPrice(double petPrice) {
		this.petPrice = petPrice;
	}
	public int getPetAmount() {
		return petAmount;
	}
	public void setPetAmount(int petAmount) {
		this.petAmount = petAmount;
	}

}
