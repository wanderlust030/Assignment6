import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PetService {
	String sql = null;
	PreparedStatement ps = null;
	
	public Pet searchPet(String name){
		Connection conn = DBHelper.getConn();
		sql = "select * from 2014302580147_pet where name = '" + name + "'";
		Pet pet = new Pet();
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				pet.setId(rs.getInt("id"));
				pet.setName(rs.getString("name"));
				pet.setEat(rs.getString("eat"));
				pet.setDrink(rs.getString("drink"));
				pet.setLive(rs.getString("live"));
				pet.setHobby(rs.getString("hobby"));
				pet.setInventory(rs.getInt("inventory"));
				pet.setPrice(rs.getDouble("price"));
				return pet;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public int getInventory(String name){
		Connection conn = DBHelper.getConn();
		sql = "select * from 2014302580147_pet where name = '" + name + "'";
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				return rs.getInt("inventory");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 0;
	}
	public boolean updateInventory(String name, int newInventory){
		Connection conn = DBHelper.getConn();
		sql = "update 2014302580147_pet set inventory = '" + newInventory + "' where name = '" + name + "'";
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}
