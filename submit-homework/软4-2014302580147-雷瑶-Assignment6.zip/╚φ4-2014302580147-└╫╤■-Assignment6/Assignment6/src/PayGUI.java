
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PayGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField pwdField;

	double money;
	String name;
	String phone;
	String mail;
	String address;
	String stmt;
	/**
	 * Create the frame.
	 */
	public PayGUI() {
		setTitle("\u5BA0\u7269\u4EA4\u6613\u5E73\u53F0|\u4ED8\u6B3E");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 314, 227);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u5BC6\u7801");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label.setBounds(114, 28, 86, 15);
		contentPane.add(label);
		
		pwdField = new JTextField();
		pwdField.setBounds(61, 64, 182, 21);
		contentPane.add(pwdField);
		pwdField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u652F\u4ED8");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OrderService orderService = new OrderService();
				UserService userService = new UserService();
				boolean tag = orderService.createOrder(money, name, phone, mail, address, stmt);
				if(! userService.verify(UserNow.getUsernameNow(), pwdField.getText())) {
					JOptionPane.showMessageDialog(null, "�������", "������Ϣ", JOptionPane.ERROR_MESSAGE);
				} else {
					if(tag) {
						CartService cartService = new CartService();
						cartService.deleteByName();
						int id = orderService.getOrderId(money, name);
						orderService.changeOrderState(id);
						String s = "֧���ɹ���������Ϊ��"+id;
						JOptionPane.showMessageDialog(null, s, "��ʾ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, "֧��ʧ��", "������Ϣ", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton.setBounds(107, 109, 93, 23);
		contentPane.add(btnNewButton);
	}
	
	public void getValue(double money, String name, String phone, String mail,String address, String stmt){
		this.money = money;
		this.name = name;
		this.phone = phone;
		this.mail = mail;
		this.address = address;
		this.stmt = stmt;
	}

}
