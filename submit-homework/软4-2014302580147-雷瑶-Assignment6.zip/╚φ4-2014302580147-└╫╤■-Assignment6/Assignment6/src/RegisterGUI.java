import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;

public class RegisterGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JTextField emailField;
	
	User user = new User();
	UserService userService = new UserService();

	/**
	 * Create the frame.
	 */
	public RegisterGUI() {
		setTitle("\u5BA0\u7269\u4EA4\u6613\u5E73\u53F0 - \u6CE8\u518C");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, -21, 465, 352);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel usernameLabel = new JLabel("\u7528\u6237\u540D");
		usernameLabel.setBounds(48, 77, 54, 15);
		contentPane.add(usernameLabel);
		
		usernameField = new JTextField();
		usernameField.setBounds(129, 74, 196, 21);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		
		JLabel passwordLabel = new JLabel("\u5BC6\u7801");
		passwordLabel.setBounds(48, 108, 54, 15);
		contentPane.add(passwordLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(129, 105, 196, 21);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(129, 136, 196, 21);
		contentPane.add(passwordField_1);
		
		JLabel passwordLabel_1 = new JLabel("\u5BC6\u7801\u786E\u8BA4");
		passwordLabel_1.setBounds(48, 139, 54, 15);
		contentPane.add(passwordLabel_1);
		
		emailField = new JTextField();
		emailField.setBounds(129, 167, 196, 21);
		contentPane.add(emailField);
		emailField.setColumns(10);
		
		JLabel emailLabel = new JLabel("\u7535\u5B50\u90AE\u7BB1");
		emailLabel.setBounds(48, 170, 54, 15);
		contentPane.add(emailLabel);
		
		JLabel lblRe = new JLabel("Join Us");
		lblRe.setFont(new Font("Candara", Font.PLAIN, 20));
		lblRe.setBounds(196, 24, 73, 15);
		contentPane.add(lblRe);
		
		JButton registerBtn = new JButton("\u6CE8\u518C");
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String usernameIpt = usernameField.getText();
				String passwordIpt = String.valueOf(passwordField.getPassword());
				String passwordIpt_1 = String.valueOf(passwordField_1.getPassword());
				String emailIpt = emailField.getText();
				if(usernameIpt.isEmpty()) {
					JOptionPane.showMessageDialog(null, "�������û�����", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else if(usernameIpt.length() < 3 || usernameIpt.length() > 15) {
					JOptionPane.showMessageDialog(null, "�û������Ȳ�����Ҫ�����������룡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					usernameField.requestFocus();
					return;
				} else if(userService.nameExists(usernameIpt)) {
					JOptionPane.showMessageDialog(null, "���û����ѱ�ע�ᣬ���������룡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else if(passwordIpt.isEmpty()) {
					JOptionPane.showMessageDialog(null, "���������룡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else if(passwordIpt_1.isEmpty()) {
					JOptionPane.showMessageDialog(null, "���ٴ��������룡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else if(passwordIpt.length() < 5 || passwordIpt.length() > 20) {
					JOptionPane.showMessageDialog(null, "���볤�Ȳ�����Ҫ�����������룡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					passwordField.requestFocus();
					return;
				} else if(! passwordIpt_1.equals(passwordIpt)) {
					JOptionPane.showMessageDialog(null, "������������벻һ�£�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					passwordField_1.requestFocus();
					return;
				} else if(emailIpt.isEmpty()) {
					JOptionPane.showMessageDialog(null, "������������䣡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else if (!Pattern.matches("\\w+@\\w+\\.\\w+", emailIpt)) {
					JOptionPane.showMessageDialog(null, "������Ϸ��ĵ������䣡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else if(userService.emailExists(emailIpt)) {
					JOptionPane.showMessageDialog(null, "�������ѱ�ע�ᣬ���������룡", "������Ϣ", JOptionPane.WARNING_MESSAGE);
					return;
				} else {
					user.setUsername(usernameIpt);
					user.setPassword(passwordIpt);
					user.setEmail(emailIpt);
					if(userService.addUser(user)){
						JOptionPane.showMessageDialog(null, "�û�ע��ɹ�����ӭ������ｻ��ƽ̨��", "��ʾ�ɹ�", JOptionPane.INFORMATION_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, "�û�ע��ʧ�ܣ�", "ʧ����Ϣ", JOptionPane.ERROR_MESSAGE);
					}
					
				}
								
			}
		});
		registerBtn.setBounds(252, 214, 73, 23);
		contentPane.add(registerBtn);
		
		JLabel lblNewLabel = new JLabel("\uFF083 - 15 \u5B57\u7B26\uFF09");
		lblNewLabel.setBounds(335, 77, 90, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uFF085 - 20 \u5B57\u7B26\uFF09");
		lblNewLabel_1.setBounds(335, 108, 90, 15);
		contentPane.add(lblNewLabel_1);
	}
}
